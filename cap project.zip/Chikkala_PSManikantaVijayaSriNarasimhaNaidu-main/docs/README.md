# Documentation Folder

This folder contain Project proposal and power point presentations of the project
