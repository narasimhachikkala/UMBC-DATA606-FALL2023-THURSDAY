# Data folder

This Folder contains datsets for this project.

The dataset is 80MB, which is too large for Github.
It is saved in my Google Drive and can be accessed through this link:
https://drive.google.com/file/d/1FZ0D9skNnczkPw0ykrwaBNM85aZuSVLb/view?usp=drive_link
